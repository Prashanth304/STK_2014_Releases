#!/bin/bash


#************************************************************************************
#* Title: WCI Test Automation
#* Author: Kiran J,Bhavana Y
#* (c) Copyright 2010, Honeywell Tech Solution  All rights reserved.
#*
#* No part of this document must be reproduced in any form - including copied,
#* transcribed, printed or by any electronic means - without specific written
#* permission from Honeywell.
#*
#************************************************************************************
rm *.log
LOG_FILE="Copy.log"
touch "$LOG_FILE"
File_SS='../Config/script_server';
File_TP_Stack='../Config/Execute_TP_Stack.sh';
File_UDO_TP='../Config/Execute_TP_UDO.sh';
File_iboot='../Config/iboot';


#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' ss.ini > ss_temp.ini
cp ss_temp.ini ss.ini
rm ss_temp.ini

sed 's/'"$(printf '\015')"'$//g' Execute_TP_UDO.sh >Execute_TP_UDO_temp.sh
cp Execute_TP_UDO_temp.sh Execute_TP_UDO.sh
rm Execute_TP_UDO_temp.sh 

sed 's/'"$(printf '\015')"'$//g' Execute_TP_Stack.sh >Execute_TP_Stack_temp.sh
cp Execute_TP_Stack_temp.sh Execute_TP_Stack.sh
rm Execute_TP_Stack_temp.sh 

sed 's/'"$(printf '\015')"'$//g' Execute_Stack.sh >Execute_Stack_temp.sh
cp Execute_Stack_temp.sh Execute_Stack.sh
rm Execute_Stack_temp.sh 

cp Execute_Stack.sh ../
chmod +x ../Execute_Stack.sh

cp Execute_AL.sh ../AL/Execute_AL.sh
cp Execute_SL.sh ../SL/Execute_SL.sh
cp Execute_TL.sh ../TL/Execute_TL.sh
cp Execute_NL.sh ../NL/Execute_NL.sh
cp Execute_DL.sh ../DL/Execute_DL.sh


#*****************************Separate logic for BLC****************************************************

cp Execute_TP_Stack.sh ../BLC/BLC/Execute_TP_Stack.sh
cp Execute_TP_Stack.sh ../BLC/JoiningScript/Execute_TP_Stack.sh

cp script_server ../BLC/BLC/script_server
cp iboot ../BLC/BLC/iboot
cp script_server ../BLC/JoiningScript/script_server
cp iboot ../BLC/JoiningScript/iboot


echo "Copied Execute_TP_Stack to ../BLC/BLC and ../BLC/JoiningScripts"
chmod +x ../BLC/BLC/Execute_TP_Stack.sh #Make Execute_BLC.sh executable
chmod +x ../BLC/BLC/script_server
chmod +x ../BLC/JoiningScript/Execute_TP_Stack.sh #Make Execute_BLC executable
chmod +x ../BLC/JoiningScript/script_server
chmod +x ../BLC/BLC/iboot
chmod +x ../BLC/JoiningScript/iboot


#*****************************AL****************************************************

cd ..
cd AL
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);

#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' Execute_AL.sh > Execute_AL_temp.sh
cp Execute_AL_temp.sh Execute_AL.sh
rm Execute_AL_temp.sh 
chmod +x Execute_AL.sh #Make Execute_AL.sh executable

for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d ALSTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_TP_Stack $FOLDERNAME
  echo "Copied $File_TP_Stack to $FOLDERNAME"
  echo "Copied $File_TP_Stack to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_Stack.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"
 done

#*****************************SL****************************************************
cd ..
cd SL
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);

#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' Execute_SL.sh > Execute_SL_temp.sh
cp Execute_SL_temp.sh Execute_SL.sh
rm Execute_SL_temp.sh 
chmod +x Execute_SL.sh #Make Execute_SL.sh executable

for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d SLTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_TP_Stack $FOLDERNAME
  echo "Copied $File_TP_Stack to $FOLDERNAME"
  echo "Copied $File_TP_Stack to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_Stack.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"

 done

#*****************************TL****************************************************
cd ..
cd TL
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);

#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' Execute_TL.sh > Execute_TL_temp.sh
cp Execute_TL_temp.sh Execute_TL.sh
rm Execute_TL_temp.sh 
chmod +x Execute_TL.sh #Make Execute_TL.sh executable

for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d TLTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_TP_Stack $FOLDERNAME
  echo "Copied $File_TP_Stack to $FOLDERNAME"
  echo "Copied $File_TP_Stack to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_Stack.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"

 done

#*****************************NL****************************************************

cd ..
cd NL
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);

#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' Execute_NL.sh > Execute_NL_temp.sh
cp Execute_NL_temp.sh Execute_NL.sh
rm Execute_NL_temp.sh 
chmod +x Execute_NL.sh #Make Execute_NL.sh executable

for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d NLTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_TP_Stack $FOLDERNAME
  echo "Copied $File_TP_Stack to $FOLDERNAME"
  echo "Copied $File_TP_Stack to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_Stack.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"

 done


#*****************************DL****************************************************

cd ..
cd DL
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);

#Remove ^m copy to temp file and copy back
sed 's/'"$(printf '\015')"'$//g' Execute_DL.sh > Execute_DL_temp.sh
cp Execute_DL_temp.sh Execute_DL.sh
rm Execute_DL_temp.sh 
chmod +x Execute_DL.sh #Make Execute_DL.sh executable

for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d DLTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_TP_Stack $FOLDERNAME
  echo "Copied $File_TP_Stack to $FOLDERNAME"
  echo "Copied $File_TP_Stack to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_Stack.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"


 done
 
 #*****************************UDO*************************************************

cd ..
cd UDO_DMAP
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);


for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   

  FOLDERNAME=$(ls -d UDOTP$d'_'*);
  #Log Foldername
  cp $File_SS $FOLDERNAME
  #echo $FOLDERNAME
  echo "Copied $File_SS to $FOLDERNAME">>../Config/$LOG_FILE
  echo "Copied $File_SS to $FOLDERNAME"

  cp $File_iboot $FOLDERNAME
  echo "Copied $File_iboot to $FOLDERNAME"
  echo "Copied $File_iboot to $FOLDERNAME">>../Config/$LOG_FILE

  cp $File_UDO_TP $FOLDERNAME
  echo "Copied $File_UDO_TP to $FOLDERNAME"
  echo "Copied $File_UDO_TP to $FOLDERNAME">>../Config/$LOG_FILE

  chmod +x $FOLDERNAME"/script_server" #Make script_server executable
  chmod +x $FOLDERNAME"/Execute_TP_UDO.sh" #Make Execute_TP.sh executable
  chmod +x $FOLDERNAME"/iboot"
 done

cd ..