#!/bin/bash


#************************************************************************************
#* Title: WCI Test Automation
#* Author: Kiran J
#* Version: 3.0
#* (c) Copyright 2010, Honeywell Tech Solution  All rights reserved.
#*
#* No part of this document must be reproduced in any form - including copied,
#* transcribed, printed or by any electronic means - without specific written
#* permission from Honeywell.
#*
#************************************************************************************

#Function to calculate time difference between two messages Kiran J
timedifference()
{
#Below is the implementation to calculate timedifference between two messages in log.
#Get line number containing message descreption and then 3rd line from that is Read UDP

	msg1=$1
	msg2=$2
	#echo "msg1=$msg1 msg2=$msg2"
	lineno1=`sed -n "/$msg1/="  $FILENAME.log`
	tlineno1=$lineno1'p'
	buf1=`sed -n {$tlineno1} $FILENAME.log|grep -i end`
	#echo $buf
	#echo "1Buff1=$buf1";
	while [ "$buf1" == "" ];
	 do
	lineno1=`expr $lineno1 + 1`
	#echo "l1=$lineno1"
	#echo "lineno=$lineno1"
	tlineno1=$lineno1'p'

	buf2=`sed -n {$tlineno1} $FILENAME.log|grep -i 'WAIT ok'`

	#echo "buf2=$buf2"
	if [ "$buf2" != "" ]; then
	#echo "Buff2 ok"
	prevlineno1=`expr $lineno1 - 2`
	ptlineno1=$prevlineno1'p'
	buf3=`sed -n {$ptlineno1} $FILENAME.log|grep -i 'RX_RF'`
	#echo "buf3=$buf3"
	if [ "$buf3" != "" ]; then
	lineno1=`expr $lineno1 - 2`
	#echo "lineno1=$lineno1"
	break;
	fi;
	fi;
	buf1=`sed -n {$tlineno1} $FILENAME.log|grep -i end`

	done


	#lineno1=`expr $lineno1 + 3`;
	lineno1=$lineno1'p'
	line1=`sed -n {$lineno1} $FILENAME.log`;
	#Get date and time from read udp
	date1=`echo $line1 | awk -F "[" '{print $2}' | awk -F "]" '{print $1}'`;

	#Get similarly for message2
	#msg2="BBR CONFIG END"
	lineno2=`sed -n "/$msg2/="  $FILENAME.log`
	tlineno2=$lineno2'p'
	buf1=`sed -n {$tlineno2} $FILENAME.log|grep -i end`
	#echo $buf1
	#echo "2Buff1= $buf1";
	while [ "$buf1" == "" ];
	 do
	lineno2=`expr $lineno2 + 1`
	#echo "lineno2=$lineno2"
	tlineno2=$lineno2'p'
	buf2=`sed -n {$tlineno2} $FILENAME.log|grep -i 'WAIT ok'`
	#echo "buf2=$buf2"
	if [ "$buf2" != "" ]; then
	prevlineno2=`expr $lineno2 - 2`
	ptlineno2=$prevlineno2'p'
	buf3=`sed -n {$ptlineno2} $FILENAME.log|grep -i 'RX_RF'`
	#echo "buf3=$buf3"
	if [ "$buf3" != "" ]; then
	lineno2=`expr $lineno2 - 2`

	break;
	fi;
	fi;
	buf1=`sed -n {$tlineno2} $FILENAME.log|grep -i end`

	done
	#lineno2=`expr $lineno2 + 3`;
	lineno2=$lineno2'p'
	line2=`sed -n {$lineno2}  $FILENAME.log`;
	date2=`echo $line2 | awk -F "[" '{print $2}' | awk -F "]" '{print $1}'`;

	date11=$date1
	date22=$date2
	#Get the millisec
	milli1=${date1#*.}
	milli2=${date2#*.}
	#Omit the millisec
	date1=${date1%.*}
	date2=${date2%.*}
	#Omit the date
	date1=${date1#* }
	date2=${date2#* }
	#Extract Hour Min Seconds Milliseconds from date1 and date2
	s1=${date1##*:}
	s2=${date2##*:}
	m1=`echo $date1 |cut -d\: -f2`
	m2=`echo $date2 |cut -d\: -f2`
	h1=`echo $date1 |cut -d\: -f1`
	h2=`echo $date2 |cut -d\: -f1`

	#echo "Milli1 $milli1"
	#echo "Milli2 $milli2"
	#echo "Date1 $date1  h1 $h1 m1 $m1 s1 $s1"
	#echo "Date2 $date2 h2 $h2 m2 $m2 s2 $s2"
	#Convert all to milliseconds
	th1=$((10#$h1*3600000)) 
	tm1=$((10#$m1*60000)) 
	ts1=$((10#$s1*1000))
	th2=$((10#$h2*3600000)) 
	tm2=$((10#$m2*60000)) 
	ts2=$((10#$s2*1000))

	t1=`expr $th1 + $tm1 + $ts1 + $milli1`
	t2=`expr $th2 + $tm2 + $ts2 + $milli2`
	diff=`expr $t2 - $t1`



	#date2-date1 in seconds
	#diff=$(( $(date -d $date2 '+%s') - $(date -d $date1 '+%s') ))
	echo "$diff"

 
}


#Below function is used to execute individual testpoint so place the script in the folder to be run
function execute_DL {
local FILECOUNT;
local FILENAME;
local FOLDERCOUNT;
local FOLDERNAME;
local skipFile=0;
local skipFolder=0;
FOLDERCOUNT=$(ls -l | grep ^d | wc -l);
LOG_FILE="Log_`date +"%m_%d_%y_%H_%M"`.log"
touch "$LOG_FILE"
 
#remove old log files
rm *.log
 
#Read ss.ini and store the object values
cd ../Config


# Below is to fill objValue is NULL(1)or Not for corresponding ObjNames from ss.ini
for line in `cat ss.ini`
do 
	templine=$line;

	buff2=`echo $line| grep -i 'Device_Role'`
	if [[ $buff2 != "" ]];
	then  
		device_role=${line/"Device_Role"'='/};

	fi
done;

for line in `cat ss.ini`
  do 
templine=$line;

buff3=`echo $line| grep -i 'iboot_IP'`
if [[ $buff3 != "" ]];
      then  

iboot_IP=${line/"iboot_IP"'='/};

fi
done;


cd ..
cd DL

#Below is the code to find if the Folder contains objName which is to be skipped
for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   
	skipFolder=0
	FOLDERNAME=$(ls -d DLTP$d'_'*);
	buff_IO=`echo $FOLDERNAME | grep -i '_IO_'`
	buff_Router=`echo $FOLDERNAME | grep -i '_RO_'`
 
	 if [[ (( $device_role == "0001" ) && ( $buff_Router != "")) || (( $device_role == "0002" ) && ( $buff_IO != "")) ||(( $device_role == "0003" ) &&( $buff_IO != ""))  ]];
	 then 
		echo "Device Role=$device_role so SKIPPING $FOLDERNAME ....."
		echo "$FOLDERNAME:Device Role=$device_role so SKIPPED" >> "$LOG_FILE"
		skipFolder=1; #Folder containing objName and corresponding objValue=1 will be skipped
	fi

	if [[ $skipFolder == "0" ]]; 
	then
		echo "$FOLDERNAME" >> "$LOG_FILE"
		cd $FOLDERNAME
		rm *.log
		chmod +x script_server
		echo "Executing $FOLDERNAME"
		FILECOUNT=$(ls *.xml | wc -l);

		#For each xml starting with 1 to FILECOUNT execute script
		for(( c=1; c<=$FILECOUNT; c++ ))
		do
			skipFile=0
			FILENAME_Temp=$(ls $c'_'*.xml);
			FILENAME=${FILENAME_Temp%.xml} 
			echo "Processing  $FILENAME.xml ....."

			#If file name contains one of the object names check if objvalue is 1 if yes skipFile
			buff_IO_File=`echo $FILENAME | grep -i '_IO_'`
			buff_Router_File=`echo $FILENAME | grep -i '_RO_'`

 
			 if [[ (( $device_role == "0001" ) && ( $buff_Router_File != "")) || (( $device_role == "0002" ) && ( $buff_IO_File != "")) ||(( $device_role == "0003" ) &&( $buff_IO_File != ""))  ]];
			 then 
				echo "Device Role=$device_role so SKIPPING $FILENAME ....."
				echo "$FILENAME:Device Role=$device_role so SKIPPED" >> "../$LOG_FILE"
				skipFile=1; #Folder containing objName and corresponding objValue=1 will be skipped
			fi

			if [[ $skipFile == "0" ]]; 
			then
				#Retrieve file name starting with counter and remove .xml extension, store in Filename
				FILENAME_Temp=$(ls $c'_'*.xml);
				FILENAME=${FILENAME_Temp%.xml} 
				echo "EXECUTING $FILENAME.xml ....."

				# If Join XML display restart
				buff2=`echo $FILENAME | grep -i JOIN`  
			      	if [[ $buff2 == "" ]]; 
		                then 
					#Execute SCRITPS
					./script_server -f "$FILENAME.xml">temp.log
					 sleep 2

					if [[ `echo $FILENAME | grep -i difference` == "" ]]; # To check if filename contains difference
					then 
						#Check if FILENAME.log file contains failed. 
						logfile=${FILENAME%t*xml}
						buff2=`cat "$FILENAME.log" | grep -i "Test fail"`

						if [[ $buff2 == "" ]];
						then 
							buff4=`echo $FILENAME | grep -i manual`  
							if [[ $buff4 == "" ]]; 
							then 
								echo "$FILENAME: TEST PASSED" >> "../$LOG_FILE";
								echo " TEST PASSED";
							else
								echo "$FILENAME: MANUALLY VERIFY" >> "../$LOG_FILE";
								echo " MANUALLY VERIFY";
						fi;                  
						else 
							echo "$FILENAME: TEST FAILED" >> "../$LOG_FILE";
							echo "@@@@@@@@@@@@@@@@@@@@@TEST FAILED@@@@@@@@@@@@";
						fi;   

					else 
						#Check if FILENAME.log file contains failed. 
						logfile=${FILENAME%t*xml}
						Failbuff=`cat "$FILENAME.log" | grep -i "Test fail"`
						if [[ $Failbuff == "" ]];
						then 
							#Filename contains difference... So call difference function.
							value=`echo $FILENAME | cut -d '_' -f3`
							MaxMsg=`echo $FILENAME | cut -d '_' -f4`
							value=$((10#$value*1000)) 
							#diff=( 0 0 0 0 0 0 0 0 0) #0 means not NULL
							lower=`expr $value - 200`
							upper=`expr $value + 200`
							difFailed=0;
							for(( c1=1; c1<$MaxMsg; c1++ ))
							do
								c2=`expr $c1 + 1`
								diff[$c1]=$(timedifference ": DIFFERENCE MESSAGE$c1" ": DIFFERENCE MESSAGE$c2")
								if [ ${diff[$c1]} -le $lower -o ${diff[$c1]} -ge $upper ]
								then
									difFailed=1; #Difference failed
									echo "$FILENAME: TEST FAILED...Expecting time difference $value msec +-200msec but ${diff[$c1]} msecs received" >> "../$LOG_FILE";
									echo "TEST FAILED...Expecting time difference $value msec +-200msec but ${diff[$c1]} msecs received";
								fi;
							done

							if [[ $difFailed == "0" ]]; 
							then
								echo "$FILENAME: TEST PASSED...Expecting time difference $value msec +-200msec " >> "../$LOG_FILE";
								echo "TEST PASSED...Expecting time difference $value msec +-200msec received";
							fi;
						else
							echo "$FILENAME: TEST FAILED" >> "../$LOG_FILE";
							echo "@@@@@@@@@@@@@@@@@@@@@TEST FAILED@@@@@@@@@@@@";
						fi
					fi;#end of time diff
				else
					pass=0;
					for(( cc=1; cc<=3&&pass<=0; cc++ ))
					do
						buff5=`echo $FILENAME | grep -i JOIN2`  
					        if [[ $buff5 == "" ]]; 
					        then
							echo "---------------------------RESTART THE FIRST DEVICE NOW---------------";
							sleep 10
							{ sleep 3; echo admin; sleep 2; echo admin; sleep 2; echo set outlet off; sleep 5; echo logout; } | telnet $iboot_IP
							sleep 20
							{ sleep 3; echo admin; sleep 2; echo admin; sleep 2; echo set outlet on; sleep 5; echo logout; } | telnet $iboot_IP
						else
							echo "---------------------------RESTART THE SECOND DEVICE NOW---------------";
						fi

								
						./script_server -f "$FILENAME.xml" >>temp.log
						buff2=`cat "$FILENAME.log" | grep -i "Test fail"`
						if [[ $buff2 == "" ]];
						then 
							echo "$FILENAME: TEST PASSED" >> "../$LOG_FILE"
          						echo "TEST PASSED"
        						pass=1;    
						break;      
						else 
							echo "$FILENAME: TEST FAILED" >> "../$LOG_FILE";
							echo "@@@@@@@@@@@@@@@@@@@@@TEST FAILED@@@@@@@@@@@@";
							pass=0;
						fi;   
					done;


			         fi;
	#end of skip file logic
	fi;
	#end of File logic
	done
cd ..
#end of FOlder logic
fi;
echo "**************************************************************" >> "$LOG_FILE"
#end of folderlogic
done

cd ..

echo "COPYING LOGS..."

mkdir DL_LOGS

cp -R DL/ DL_LOGS
cd DL_LOGS/DL
rm -f *.sh 
#rm -r Config
#FOLDERCOUNT=$(ls -l | grep ^d | wc -l);
#Below is the code to remove files other than logs
for(( d=1; d<=$FOLDERCOUNT; d++ )) #Execute all foldercount-1 (1 folder is config)
do   
	  skipFolder=0
	  FOLDERNAME=$(ls -d DLTP$d'_'*);
	  cd $FOLDERNAME
	  # find . ! -name "*.log" -exec rm -f {} \; >rr.log
	  #shopt -s extglob
	  #rm !(*.log);
	  rm -f script_server
	  rm -f *.csv 
	  rm -f *.xml 
	  rm -f *.sh 
	  cd ..
done
	echo "COPYING DONE..."
}

execute_DL

