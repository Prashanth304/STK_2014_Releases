#!/bin/bash


#************************************************************************************
#* Title: WCI Test Automation
#* Author: Kiran J
#* (c) Copyright 2010, Honeywell Tech Solution  All rights reserved.
#*
#* No part of this document must be reproduced in any form - including copied,
#* transcribed, printed or by any electronic means - without specific written
#* permission from Honeywell.
#*
#************************************************************************************
###Executing DL"
echo "Executing DL testpoints"
cd  DL
./Execute_DL.sh
cd ..
echo "Executing AL testpoints"
cd  AL
./Execute_AL.sh
cd ..
echo "Executing TL testpoints"
cd  TL
./Execute_TL.sh
cd ..
echo "Executing NL testpoints"
cd  NL
./Execute_NL.sh
cd ..
echo "Executing SL testpoints"
cd  SL
./Execute_SL.sh
cd ..
echo "Execution Complete"