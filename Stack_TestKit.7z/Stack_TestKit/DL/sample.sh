#Below is the code to find if the Folder contains objName which is to be skipped
for(( d=50; d<=59; d++ )) #Execute all foldercount-1 (1 folder is config)
do   
	echo "------------------------START-----------------------"
	FOLDERNAME=$(ls -d DLTP$d'_'*);
	cd $FOLDERNAME
	./Execute_TP_Stack.sh
	cd ..
	echo "------------------------END-----------------------"
done